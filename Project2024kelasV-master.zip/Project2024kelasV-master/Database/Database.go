package Database

import (
	"Project2024kelasV/Node"
)

var DBmember Node.TableMember
